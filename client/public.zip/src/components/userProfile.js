import React from 'react'
import '../cssFiles/userProfile.css'

export default function userProfile() {
  return (
    <div>
      
    </div>
  )
}
