import { useState } from 'react';
import './App.css';
import Navbar from './components/Navbar'
import UserProfile from './components/userProfile';
import SideBarMenu from './components/sideBarMenu';
import ChangePassword from './components/changePassword';
import './cssFiles/Navbar.css'
import{
  BrowserRouter as Router,
  Routes,
  Route
} from "react-router-dom"

function App() {
  // ---------------------------------------------------    Handle state of resizing window ----------------------------------------------------------------------
  const [windowSize, setWindowSize] = useState([window.innerWidth, window.innerHeight]);
  // --------------------------------------------------------------- Completed -----------------------------------------------------------------------------------


  // ---------------------------------------------------    Handle Profile Logo Click function in Navigation Menu   ----------------------------------------------
  const [navDropdownShow, setNavDropdownShow] = useState("none");
  const navProfileLogoClick = ()=>{
    if(navDropdownShow === "none")
      setNavDropdownShow("block");
    else
      setNavDropdownShow("none");
  }
  // ---------------------------------------------------------------------------    Completed   ------------------------------------------------------------------


  // -------------------------------------------------    Handle HamBurgar Icon Click function in Navigation Menu   ----------------------------------------------
  const [sideBarShow, setSideBarShow] = useState((window.innerWidth > 1050) ? true : false);
  const toggleSideBar = ()=>{
    if(sideBarShow === false)
      setSideBarShow(true);
    else
      setSideBarShow(false);
  }
  // ---------------------------------------------------------------------------    Completed   ------------------------------------------------------------------


  // ---------------------------------------------------    Handle on resize of window ---------------------------------------------------------------------------
  window.onresize = function(event){
    // For Navigation menu
    setWindowSize([window.innerWidth, window.innerHeight]);
    // for sidebar menu
    if(window.innerWidth <= 1050)
      setSideBarShow(false);
    else  
      setSideBarShow(true);
  }
  // --------------------------------------------------------------- Completed -----------------------------------------------------------------------------------


  // ---------------------------------------------------    Handle click on whole window -------------------------------------------------------------------------
  window.onclick = function(event){
    // For Navigation menu
    if (!event.target.matches('.navDropdown') && !event.target.matches('.profileLogo')) {
      if(navDropdownShow === "block")
      setNavDropdownShow("none");
    }
    // For side Bar Menu
    if(window.innerWidth <= 1050 && !event.target.matches('.nav-hamburgerIcon') && !event.target.closest('.nav-hamburgerIcon') && !event.target.matches('.sideNavBar')){
      setSideBarShow(false);
    }
  }
  // --------------------------------------------------------------- Completed -----------------------------------------------------------------------------------
  return (
    <>
      <Router>
        <Navbar toggleSideBar={toggleSideBar} navProfileLogoClick={navProfileLogoClick} navDropdownShow={navDropdownShow} windowSize = {windowSize}/>
        <SideBarMenu sideBarShow = {sideBarShow} setSideBarShow={setSideBarShow}/>
        <Routes>
          <Route exact path="/changePassword" element={<ChangePassword windowSize = {windowSize}/>}></Route>
          <Route exact path="/" element={<UserProfile/>}></Route>
        </Routes>
      </Router>
    </>
  );
}

export default App;
